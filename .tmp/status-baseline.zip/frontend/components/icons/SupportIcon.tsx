import React from 'react';

type IconProps = React.SVGProps<SVGSVGElement>;

export const SupportIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3a3 3 0 100 6 3 3 0 000-6z" />
  </svg>
);
